package com.jhonju.ps3netsrv.server.commands;

public interface ICommand {

    void executeTask() throws Exception;

}
