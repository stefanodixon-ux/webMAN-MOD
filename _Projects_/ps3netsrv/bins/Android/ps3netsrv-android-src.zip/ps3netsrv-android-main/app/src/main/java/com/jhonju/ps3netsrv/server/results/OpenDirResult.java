package com.jhonju.ps3netsrv.server.results;

public class OpenDirResult {
    public final int openResult;

    public OpenDirResult(int openResult) {
        this.openResult = openResult;
    }

//    public byte[] toByteArray() {
//        return Utils.intToBytes(openResult);
//    }
//
//    private void writeObject(java.io.ObjectOutputStream stream)
//            throws IOException {
//        stream.writeInt(openResult);
//    }
}
