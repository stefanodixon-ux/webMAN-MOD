package com.jhonju.ps3netsrv.server.enums;

public enum EVirtualISO {
    VISO_NONE,
    VISO_PS3,
    VISO_ISO;
}
