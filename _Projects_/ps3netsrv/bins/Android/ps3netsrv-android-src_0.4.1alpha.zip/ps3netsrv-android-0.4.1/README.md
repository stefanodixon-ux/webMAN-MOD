# ps3netsrv-android
Android ps3netsrv

Work in progress.

Features missing from original ps3netsrv that I still wants to develop:
1. Multi part ISO.
2. Virtual ISO from "JB Games".
3. Encrypted ISO.
4. ~~Whitelist / Blacklist of client IP's.~~ (released on 0.3 Alpha)
5. ~~Limit the maximum number of clients.~~ (released on 0.4 Alpha)

I also have to improve the interface, because it's a lot uggly.

The project is developed using only native Android/Java libraries, to avoid problems with licensing.

If you want to contribute, feel free to open a PR.
